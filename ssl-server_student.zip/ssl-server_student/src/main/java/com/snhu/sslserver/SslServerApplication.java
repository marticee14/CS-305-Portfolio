/*~*~*~*~*~*~*~*~*~*~*~*~*
 * CS 305 Project 2
 * Elizabeth Marticello
 *~*~*~*~*~*~*~*~*~*~*~*~*/
package com.snhu.sslserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
// Added import statements for Checksum
import java.security.MessageDigest; 
import java.security.NoSuchAlgorithmException;

// Added import statements for Cipher
import org.springframework.web.bind.annotation.RequestParam;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import java.util.Base64;

@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}

}
//Add route to enable check sum return of static data example:  String data = "Hello World Check Sum!";

@RestController
class ServerController{
// Add hash function to return the checksum value for the data string that should contain your name.    
    @RequestMapping("/hash")
    public String myHash(){
    	String data = "Hello Liz Marticello!";
    	String algorithm = "SHA-256";
    	
    	try {
    		MessageDigest digest = MessageDigest.getInstance(algorithm);
    		byte[] hashBytes = digest.digest(data.getBytes());
    		String checksum = bytesToHex(hashBytes);
    		
    		return 
    				"<p>data:" + data + "</p>" +
    				"<p>algorithm: " + algorithm + "</p>" +
    				"<p>checksum: " + checksum + "</p>";
    	} catch (NoSuchAlgorithmException e) {
    		return "<p>Error: Algorithm " + algorithm + " not found.</p>";
    	}
    }
    
    
    // Convert Bytes to Hex
    private static String bytesToHex(byte[] bytes) {
    	StringBuilder hexString = new StringBuilder();
    	
    	for (byte b : bytes) {
    		hexString.append(String.format("%02x", b));
    	}
    	
    	return hexString.toString();
    }
}

// Here is the implementation of the Algorithm Cipher AES-256
@RestController
class CipherController {
	private static final String AES_KEY = "ABCDEFGHIJKLMNOP";
	
	@RequestMapping("/encrypt")
	public String encrypt(@RequestParam(value = "data", defaultValue = "Hello Elizabeth Marticello!") String data) {
		try {
			SecretKeySpec keySpec = new SecretKeySpec(AES_KEY.getBytes(), "AES");
			
			Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
			cipher.init(Cipher.ENCRYPT_MODE, keySpec);
			byte[] encryptedBytes = cipher.doFinal(data.getBytes());
            String encryptedBase64 = Base64.getEncoder().encodeToString(encryptedBytes);

            cipher.init(Cipher.DECRYPT_MODE, keySpec);
            byte[] decryptedBytes = cipher.doFinal(encryptedBytes);
            String decrypted = new String(decryptedBytes);

            return "<p>Original: " + data + "</p>" +
                   "<p>Encrypted (Base64): " + encryptedBase64 + "</p>" +
                   "<p>Decrypted: " + decrypted + "</p>";
		} catch (Exception e) {
			return "<p>Error: " + e.getMessage() + "</p>";
		}
	}
} 